# __init__.py

# Version of the table2file package
__version__ = "0.1.0"
